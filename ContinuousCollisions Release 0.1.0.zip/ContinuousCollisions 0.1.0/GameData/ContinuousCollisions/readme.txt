KSP Continuous Collisions 0.1.0
_______________________________

After you've loaded all the vessels you want to use, open the GUI, select continuous-dynamic and click apply. You may need to re-apply it each time you load a quick save. If you'd like to switch back to default collisions for increased performance, select discrete and clikc apply.

Thank you for using Continuous Collisions. This is VERY early in devlopment, and thus we are not responsible for any crashes or issues.
